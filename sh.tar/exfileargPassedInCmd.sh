#!/bin/sh
# this script takes inputs from file
echo "hello, $1"
echo "Maha says, she is $2"
#-------------------to see output exec 
#./exfileargPassedInCmd.sh $(cat userintro.txt)


