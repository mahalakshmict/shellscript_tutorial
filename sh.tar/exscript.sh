#!/bin/sh
#echo "hello, tell me ur name" 
echo "hello, $1, how are you?"
echo "$1 said, she is $2"
